package com.dicoding.asclepius.view.analyze

import android.net.Uri
import androidx.lifecycle.ViewModel

class AnalyzeViewModel: ViewModel() {
    var currentImageUri: Uri? = null
}